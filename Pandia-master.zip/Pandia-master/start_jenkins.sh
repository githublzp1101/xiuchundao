# sh pull_image.sh from registry
export JENKINS_HOST_PATH='/home/pandia/jenkins'
export JENKINS_PATHMEDIC_DBDATA_ON_HOST='/home/pandia/dbdata'
openssl x509 -inform der -in ./jen_cacerts/github-shengtong.cer -out ./jen_cacerts/github-shengtong.pem
mv ./jen_cacerts/github-shengtong.pem ./jen_cacerts/github-shengtong.crt
docker pull registry.shengtong.com:5000/qa/st_jenkins:latest

docker-compose -f docker-compose.yml down

docker-compose -f docker-compose.yml up -d
# docker-compose -f docker-compose_dev.yaml build
docker exec -i jenkins bash update-ca-certificates
docker exec -it jenkins bash



