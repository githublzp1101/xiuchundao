echo 192.168.54.196 registry.shengtong.com >> /etc/hosts

echo '{
  "insecure-registries" : [ "registry.shengtong.com:5000" ]
}' > /etc/docker/daemon.json

systemctl daemon-reload
echo "restarting docker..."
systemctl restart docker
echo "docker restarted"
