# update docker registry path
* `sh registry_config.sh`
# use jenkins
`sh start_jenkins.sh `
## 访问地址
`http://XXX:8080` 
## 以下情况需要添加证书:
* 使用https设置`Source Code Management` 需要添加证书 (SSH方式不需要)
* `task config` -> `build triggers` -> `GitHub Pull Request Builder` - `GitHub API credentials` 需要添加证书
### 从chrome导出证书:`
  * chrome打开github
  * 点击`Not Secure` -> 点击`certification is not valid` 打开"证书" -> `详细信息` -> `复制到文件` -> 选择`DER 编码二进制 X.509(.CER)(D)` -> 保存`github-shengtong.cer`到本地目录
* 替换`jen_cacerts/github-shengtong.cer`
* `sh start_jenkins.sh`
* 进入容器执行 `sh update_ca.sh`
	如果需要密码，默认changeit


