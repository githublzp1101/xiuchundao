keytool -import -noprompt -trustcacerts -alias myFancyAlias -file ./jen_cacerts/github-shengtong.cer -keystore /opt/java/openjdk/lib/security/cacerts -storepass changeit
